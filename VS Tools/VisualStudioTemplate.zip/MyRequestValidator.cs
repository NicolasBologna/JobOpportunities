﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;

namespace $rootnamespace$
{
	public class $servicename$RequestValidator : AbstractValidator<$servicename$Request>
	{
		public $servicename$RequestValidator() 
		{

		}
	}
}
